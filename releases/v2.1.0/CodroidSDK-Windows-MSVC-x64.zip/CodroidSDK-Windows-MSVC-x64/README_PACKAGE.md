# Codroid SDK Windows x64 Package

## Contents

- `include/`: public headers
- `bin/`: runtime DLL
- `lib/`: import library
- `examples/`: example source files
- `docs/SDK_GUIDE.md`: SDK guide

## Visual Studio / MSVC

Add include directories:

- `CodroidSDK-Windows-x64\include`

Add library directory:

- `CodroidSDK-Windows-x64\lib`

Add linker input:

- `Codroid.lib`

Runtime:

- Copy `bin\Codroid.dll` beside the application `.exe`, or add `bin\` to PATH.
