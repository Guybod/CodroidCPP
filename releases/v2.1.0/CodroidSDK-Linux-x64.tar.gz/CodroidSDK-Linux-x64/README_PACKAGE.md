# Codroid SDK Linux x64 Package

## Contents

- `include/`: public headers
- `lib/`: runtime and link libraries
- `examples/`: example source files
- `docs/SDK_GUIDE.md`: SDK guide

## Link

Typical CMake setup:

```cmake
set(CODROID_SDK_ROOT "/path/to/CodroidSDK-Linux-x64")

target_include_directories(your_app PRIVATE
    ${CODROID_SDK_ROOT}/include
)

target_link_directories(your_app PRIVATE ${CODROID_SDK_ROOT}/lib)
target_link_libraries(your_app PRIVATE Codroid Fk_Ik_so kdl pthread)

set_target_properties(your_app PROPERTIES
    BUILD_WITH_INSTALL_RPATH TRUE
    INSTALL_RPATH "$ORIGIN;${CODROID_SDK_ROOT}/lib"
)
```

## Runtime

Keep these files reachable by the executable:

- `libCodroid.so`
- `libFk_Ik_so.so`
- `libkdl.so`

They can be placed beside the executable or found through `LD_LIBRARY_PATH` / RPATH.
