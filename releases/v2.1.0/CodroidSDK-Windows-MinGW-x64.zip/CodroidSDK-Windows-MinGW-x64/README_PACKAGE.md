# Codroid SDK Windows MinGW x64 Package

## Contents

- `include/`: public headers
- `bin/`: runtime DLL
- `lib/`: import library (GNU)
- `examples/`: example source files
- `docs/SDK_GUIDE.md`: SDK guide

## MinGW / GCC

Add include directories:

- `CodroidSDK-Windows-MinGW-x64\include`

Add library directory:

- `CodroidSDK-Windows-MinGW-x64\lib`

Link input:

- `-lCodroid`

Runtime:

- Copy `bin\Codroid.dll` beside your `.exe`, or add `bin\` to PATH.
